<div class="img-fluid w-100 text-center message_box2 p-4">
	<img src="<?=site_url('uploads/dashboard/message.png');?>" height="400"><br>
	<!-- <img style="opacity: 1; width: 100px;" src="<?php echo base_url('assets/backend/images/file-search.svg'); ?>"><br> -->
	<?php echo get_phrase('choose_an_option_from_the_left_side'); ?>
</div>
